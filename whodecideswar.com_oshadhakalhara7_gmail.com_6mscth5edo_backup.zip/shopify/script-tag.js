function a0_0x2416(_0x557254, _0x19d8c6) {
    var _0x29bfd5 = a0_0x29bf();
    return a0_0x2416 = function (_0x241615, _0x18f9ab) {
        _0x241615 = _0x241615 - 0x80;
        var _0x5083b9 = _0x29bfd5[_0x241615];
        return _0x5083b9;
    }, a0_0x2416(_0x557254, _0x19d8c6);
}
function a0_0x29bf() {
    var _0x5492f9 = [
        'src',
        'window.name\x20has\x20been\x20initialized\x20with\x20sessionId',
        'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx',
        'split',
        'Shopify',
        'status',
        'complete',
        '609435yBaYnN',
        'includes',
        'script-tag-tmx',
        'loaded',
        '&session_id=',
        'R29vZ2xlIFBhZ2UgU3BlZWQgSW5zaWdodHM=',
        'https://www.cloudflare.com/cdn-cgi/trace',
        '243ywAZZC',
        'length',
        'unable\x20to\x20find\x20a\x20session\x20id\x20in\x20url.\x20using\x20session\x20id\x20from\x20shop\x20name\x20&\x20ip',
        'pop',
        'Checkout',
        'window.name\x20has\x20not\x20been\x20initialized\x20with\x20a\x20sessionId',
        'concat',
        'cookie',
        '#script-tag-api,\x20#sig-api',
        'onloadend',
        'location',
        'onreadystatechange',
        '4411390LQxUsR',
        '35ZWwxDG',
        'getAttribute',
        'appendChild',
        'createElement',
        '37232zsPIIm',
        'userAgent',
        'setAttribute',
        '452668JhbwSX',
        'using\x20session\x20id\x20from\x20checkoutToken\x20\x27',
        'true',
        '18246866OeRrjC',
        '49iOGHEN',
        'responseText',
        'sigDebugLogging',
        'using\x20session\x20id\x20from\x20url\x20\x27',
        'querySelector',
        'ip=',
        '2372EumtvP',
        'data-id',
        'replace',
        'SIGNIFYD_GLOBAL',
        'pathname',
        'random',
        'text/javascript',
        '=false',
        'head',
        'match',
        '__SCRIPTTAG__',
        'init',
        'w2txo5aa',
        'readyState',
        'using\x20session\x20id\x20from\x20urlCartToken\x20\x27',
        'setting\x20window.name\x20and\x20using\x20session\x20id\x20from\x20shop\x20name\x20and\x20ip:\x20\x27',
        'using\x20session\x20id\x20from\x20fallback\x20\x27',
        'logging',
        'name',
        'log',
        'href',
        '286806NBESrf',
        '1605CEgzzu',
        'Adding\x20script\x20with\x20session\x20id:\x20\x27',
        'cart',
        '=true',
        'SIG_SCRIPT_DEBUG',
        'Q2hyb21lLUxpZ2h0aG91c2U=',
        'checkout',
        '&pageid=2',
        'indexOf'
    ];
    a0_0x29bf = function () {
        return _0x5492f9;
    };
    return a0_0x29bf();
}
(function (_0x3a9913, _0x253f99) {
    var _0x285d43 = a0_0x2416, _0x5636b6 = _0x3a9913();
    while (!![]) {
        try {
            var _0x720db5 = parseInt(_0x285d43(0x9b)) / 0x1 + parseInt(_0x285d43(0xc0)) / 0x2 * (parseInt(_0x285d43(0x8b)) / 0x3) + parseInt(_0x285d43(0xb6)) / 0x4 * (parseInt(_0x285d43(0xaf)) / 0x5) + -parseInt(_0x285d43(0x8a)) / 0x6 * (-parseInt(_0x285d43(0xba)) / 0x7) + parseInt(_0x285d43(0xb3)) / 0x8 * (parseInt(_0x285d43(0xa2)) / 0x9) + -parseInt(_0x285d43(0xae)) / 0xa + -parseInt(_0x285d43(0xb9)) / 0xb;
            if (_0x720db5 === _0x253f99)
                break;
            else
                _0x5636b6['push'](_0x5636b6['shift']());
        } catch (_0x4f5539) {
            _0x5636b6['push'](_0x5636b6['shift']());
        }
    }
}(a0_0x29bf, 0x60c92), ((() => {
    'use strict';
    var _0x59f2c7 = a0_0x2416;
    var _0x477235 = function (_0x4d65d7) {
            var _0x38dfaf = a0_0x2416, _0x468b28, _0x57eb38 = ';\x20'['concat'](document['cookie'])[_0x38dfaf(0x97)](';\x20'['concat'](_0x4d65d7, '='));
            if (0x2 === _0x57eb38['length'])
                return null === (_0x468b28 = _0x57eb38['pop']()) || void 0x0 === _0x468b28 ? void 0x0 : _0x468b28[_0x38dfaf(0x97)](';')['shift']();
        }, _0x4845d5 = _0x59f2c7(0xbc);
    const _0x29ee3a = function (_0x2d149d) {
            var _0x2218aa = _0x59f2c7, _0x3b0c15;
            (null !== (_0x3b0c15 = window[_0x2218aa(0x8f)]) && void 0x0 !== _0x3b0c15 ? _0x3b0c15 : {})[_0x2218aa(0x86)] && console[_0x2218aa(0x88)](_0x2d149d);
        }, _0x3682bd = function (_0x48fab7, _0x1d8ed8) {
            var _0x18f76c = _0x59f2c7;
            if (_0x29ee3a(_0x18f76c(0x8c)[_0x18f76c(0xa8)](_0x48fab7, '\x27')), !navigator[_0x18f76c(0xb4)][_0x18f76c(0x9c)](atob(_0x18f76c(0x90))) && !navigator['userAgent'][_0x18f76c(0x9c)](atob(_0x18f76c(0xa0)))) {
                var _0x2ddf80 = 'https://imgs.signifyd.com/fp/tags.js?org_id='['concat'](_0x18f76c(0x81), _0x18f76c(0x9f))['concat'](_0x48fab7, _0x18f76c(0x92)), _0x535328 = document[_0x18f76c(0xb2)]('script'), _0x15037e = !0x1, _0x38e451 = document['getElementsByTagName'](_0x18f76c(0xc8))[0x0];
                _0x535328['onload'] = _0x535328[_0x18f76c(0xad)] = function () {
                    var _0x4ae807 = _0x18f76c;
                    _0x15037e || this[_0x4ae807(0x82)] && _0x4ae807(0x9e) !== this['readyState'] && _0x4ae807(0x9a) !== this[_0x4ae807(0x82)] || (_0x15037e = !0x0, _0x1d8ed8());
                }, _0x535328[_0x18f76c(0xb5)]('type', _0x18f76c(0xc6)), _0x535328['setAttribute'](_0x18f76c(0x94), _0x2ddf80), _0x535328[_0x18f76c(0xb5)]('id', _0x18f76c(0x9d)), _0x535328[_0x18f76c(0xb5)](_0x18f76c(0xc1), _0x18f76c(0x9d)), _0x38e451[_0x18f76c(0xb1)](_0x535328);
            }
        };
    var _0x1e868b, _0x49161a, _0x20cae5 = function () {
            var _0x217fa5 = _0x59f2c7;
            if (window[_0x217fa5(0xac)][_0x217fa5(0x89)][_0x217fa5(0x9c)](_0x217fa5(0x91))) {
                _0x29ee3a('Current\x20url\x20includes\x20checkout,\x20attempting\x20to\x20parse:\x20\x27'[_0x217fa5(0xa8)](window[_0x217fa5(0xac)][_0x217fa5(0xc4)]));
                var _0x46f01a = window[_0x217fa5(0xac)]['pathname'], _0xb49737 = _0x46f01a[_0x217fa5(0xc9)](/\/checkouts\/(?:cn|co)\/([^/]+)(?:\/information|\/payment)?/), _0xc1b63c = _0x46f01a[_0x217fa5(0xc9)](/\/checkouts\/([^/]+)/), _0x535e6d = _0xb49737 || _0xc1b63c;
                return null == _0x535e6d ? void 0x0 : _0x535e6d[0x1];
            }
        };
    window[_0x59f2c7(0xca)] = (_0x49161a = function () {
        var _0x5ca6ca = _0x59f2c7, _0x3523d4;
        _0x3523d4 = _0x5ca6ca(0xb8) === _0x477235(_0x4845d5) || !!function (_0x50a9a2) {
            var _0x38b1ca = _0x5ca6ca, _0x2496a0, _0x51ec5c, _0x247154 = arguments[_0x38b1ca(0xa3)] > 0x1 && void 0x0 !== arguments[0x1] ? arguments[0x1] : _0x38b1ca(0xaa);
            return null !== (_0x2496a0 = null === (_0x51ec5c = document[_0x38b1ca(0xbe)](_0x247154)) || void 0x0 === _0x51ec5c ? void 0x0 : _0x51ec5c[_0x38b1ca(0xb0)](_0x50a9a2)) && void 0x0 !== _0x2496a0 ? _0x2496a0 : void 0x0;
        }(_0x5ca6ca(0x86)), window[_0x5ca6ca(0x8f)] = {
            'logging': _0x3523d4,
            'enableLogging': function () {
                var _0x1ff58c = _0x5ca6ca;
                window[_0x1ff58c(0x8f)][_0x1ff58c(0x86)] = !0x0, document[_0x1ff58c(0xa9)] = ''[_0x1ff58c(0xa8)](_0x4845d5, _0x1ff58c(0x8e));
            },
            'disableLogging': function () {
                var _0x1e95c8 = _0x5ca6ca;
                window[_0x1e95c8(0x8f)]['logging'] = !0x1, document[_0x1e95c8(0xa9)] = ''['concat'](_0x4845d5, _0x1e95c8(0xc7));
            }
        };
        var _0x4cb5ca, _0x3862db, _0x280033, _0x54e395, _0x1b4ce9, _0x3651cd = '______sig______', _0x1ed528 = function () {
                return _0x1e868b = !0x0, !0x0;
            };
        if (-0x1 !== window[_0x5ca6ca(0x87)][_0x5ca6ca(0x93)](_0x3651cd)) {
            _0x29ee3a(_0x5ca6ca(0x95));
            var _0x59720e, _0xa03217 = _0x477235(_0x5ca6ca(0x8d)), _0x1602bc = (function () {
                    var _0xd2a482 = _0x5ca6ca, _0x13df95;
                    return null === (_0x13df95 = window['Shopify']) || void 0x0 === _0x13df95 || null === (_0x13df95 = _0x13df95[_0xd2a482(0xa6)]) || void 0x0 === _0x13df95 ? void 0x0 : _0x13df95['token'];
                }()), _0x16585a = _0x20cae5();
            _0x29ee3a({
                'cookieCartToken': _0xa03217,
                'checkoutToken': _0x1602bc,
                'urlCartToken': _0x16585a
            }), _0x1602bc ? (_0x59720e = _0x1602bc, _0x29ee3a(_0x5ca6ca(0xb7)[_0x5ca6ca(0xa8)](_0x1602bc, '\x27'))) : _0xa03217 ? (_0x29ee3a('using\x20session\x20id\x20from\x20cookieCartToken\x20\x27'['concat'](_0xa03217, '\x27')), _0x59720e = _0xa03217) : _0x16585a ? (_0x29ee3a(_0x5ca6ca(0x83)[_0x5ca6ca(0xa8)](_0x16585a, '\x27')), _0x59720e = _0x16585a) : (_0x59720e = window[_0x5ca6ca(0x87)][_0x5ca6ca(0x97)](_0x3651cd)[0x1] || _0x5ca6ca(0x96)[_0x5ca6ca(0xc2)](/[xy]/g, function (_0x1fa00f) {
                var _0xb64d95 = _0x5ca6ca, _0x41b829 = 0x10 * Math[_0xb64d95(0xc5)]() | 0x0;
                return ('x' === _0x1fa00f ? _0x41b829 : 0x3 & _0x41b829 | 0x8)['toString'](0x10);
            }), _0x29ee3a(_0x5ca6ca(0x85)['concat'](_0x59720e, '\x27'))), _0x3682bd(_0x59720e, _0x1ed528);
        } else {
            _0x29ee3a(_0x5ca6ca(0xa7));
            var _0x59e105 = _0x20cae5();
            if (_0x59e105)
                _0x29ee3a(_0x5ca6ca(0xbd)[_0x5ca6ca(0xa8)](_0x59e105, '\x27')), _0x3682bd(_0x59e105, _0x1ed528);
            else {
                var _0x9e0632;
                _0x29ee3a(_0x5ca6ca(0xa4));
                var _0x57d2c0 = null === (_0x9e0632 = window[_0x5ca6ca(0x98)]) || void 0x0 === _0x9e0632 ? void 0x0 : _0x9e0632['shop'];
                if (_0x29ee3a('shop\x20name\x20is\x20\x27'[_0x5ca6ca(0xa8)](_0x57d2c0, '\x27')), !_0x57d2c0)
                    return void console['error']('Error,\x20shop\x20name\x20is\x20not\x20specified.\x20Please\x20ensure\x20that\x20window.Shopify.shop\x20is\x20set\x20to\x20your\x20store\x20name.');
                _0x4cb5ca = function (_0x4e9cbf) {
                    var _0x4525bb = _0x5ca6ca;
                    if (_0x4e9cbf) {
                        var _0x5b0de6 = (_0x5c5f0a = _0x57d2c0, ''['concat'](_0x4e9cbf)[_0x4525bb(0xa8)](_0x5c5f0a)[_0x4525bb(0xc2)](/[^a-zA-Z0-9]/g, ''));
                        _0x29ee3a(_0x4525bb(0x84)['concat'](_0x5b0de6, '\x27')), window[_0x4525bb(0x87)] = _0x3651cd + _0x5b0de6 + _0x3651cd, _0x3682bd(_0x5b0de6, _0x1ed528);
                    }
                    var _0x5c5f0a;
                }, _0x3862db = function (_0x579643) {
                    var _0x490161 = _0x5ca6ca, _0x38c773, _0x5db314 = null === (_0x38c773 = _0x579643[_0x490161(0xbb)][_0x490161(0x97)](_0x490161(0xbf))[_0x490161(0xa5)]()) || void 0x0 === _0x38c773 ? void 0x0 : _0x38c773[_0x490161(0x97)]('\x0a')[0x0];
                    _0x4cb5ca(_0x5db314);
                }, _0x280033 = function () {
                    _0x4cb5ca();
                }, _0x54e395 = new XMLHttpRequest(), _0x1b4ce9 = null, _0x54e395['open']('GET', _0x5ca6ca(0xa1), !0x0), _0x54e395[_0x5ca6ca(0xad)] = function () {
                    var _0x12c2fa = _0x5ca6ca;
                    0x4 === _0x54e395['readyState'] && (0xc8 === _0x54e395[_0x12c2fa(0x99)] ? _0x1b4ce9 = _0x54e395 : _0x280033());
                }, _0x54e395['send'](), _0x54e395[_0x5ca6ca(0xab)] = function () {
                    return _0x1b4ce9 && _0x3862db(_0x1b4ce9);
                }, _0x54e395['error'] = function () {
                    return _0x280033();
                };
            }
        }
    }, {
        'init': function () {
            _0x49161a();
        },
        'scriptTagHasLoaded': function () {
            return _0x1e868b;
        }
    }), window[_0x59f2c7(0xc3)] = window[_0x59f2c7(0xca)], window[_0x59f2c7(0xc3)][_0x59f2c7(0x80)]();
})()));