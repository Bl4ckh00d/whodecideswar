document.addEventListener("DOMContentLoaded", function() {
  var endlessScroll = new Ajaxinate();
});
